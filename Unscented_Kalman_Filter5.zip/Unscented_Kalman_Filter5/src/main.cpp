//
//Created by Hubert   3/28/2017
//

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <stdlib.h>
#include "Eigen/Dense"
#include "ukf.h"
#include "ground_truth_package.h"
#include "measurement_package.h"
#include "tools.h"
using namespace std;
using Eigen::MatrixXd;
using Eigen::VectorXd;
using std::vector;

void printResult(VectorXd ttx,int k,UKF ukf, vector<MeasurementPackage> measurement_pack_list,int linecount, vector<GroundTruthPackage> gt_pack_list);

void check_arguments(int argc, char* argv[]) {
    string usage_instructions = "Usage instructions: ";
    usage_instructions += argv[0];
    usage_instructions += " path/to/input.txt output.txt";
    cout << "check arguments " << endl;
    bool has_valid_args = false;
    
    // make sure the user has provided input and output files
    if (argc == 1) {
        cerr << usage_instructions << endl;
    } else if (argc == 2) {
        cerr << "Please include an output file.\n" << usage_instructions << endl;
    } else if (argc == 3) {
        has_valid_args = true;
    } else if (argc > 3) {
        cerr << "Too many arguments.\n" << usage_instructions << endl;
    }
    
    if (!has_valid_args) {
        exit(EXIT_FAILURE);
    }
}

void check_files(ifstream& in_file, string& in_name,
                 ofstream& out_file, string& out_name) {
    //cout << "check files " << endl;
    
    if (!in_file.is_open()) {
        cerr << "Cannot open input file: " << in_name << endl;
        exit(EXIT_FAILURE);
    }
    
    if (!out_file.is_open()) {
        cerr << "Cannot open output file: " << out_name << endl;
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char* argv[]) {
    static int linecount =0;
    check_arguments(argc, argv);
    string in_file_name_=argv[1];
    string out_file_name_=argv[2];
    cout << "in file  "<< in_file_name_ << endl;
    cout << "out file " << out_file_name_ << endl;
    
    ifstream in_file_(in_file_name_.c_str(), ifstream::in);
    ofstream out_file_(out_file_name_.c_str(), ofstream::out);
    
    check_files(in_file_, in_file_name_, out_file_, out_file_name_);
    
    
    
    
    vector<MeasurementPackage> measurement_pack_list;
    vector<GroundTruthPackage> gt_pack_list;
    
    string line;
    
    // prep the measurement packages (each line represents a measurement at a
    // timestamp)
    while (getline(in_file_, line)) {
        
        string sensor_type;
        MeasurementPackage meas_package;
        GroundTruthPackage gt_package;
        istringstream iss(line);
        //cout << "infile name " << in_file_name_<< "  line " << line << endl;
        long timestamp;
        // reads first element from the current line
        iss >> sensor_type;
        //cout << "sensor type " << sensor_type << endl;
        
        if (sensor_type.compare("L") == 0) {
            // LASER MEASUREMENT
            
            // read measurements at this timestamp
            meas_package.sensor_type_ = MeasurementPackage::LASER;
            meas_package.raw_measurements_ = VectorXd(2);
            
            double x;
            double y;
            iss >> x;
            iss >> y;
            meas_package.raw_measurements_ << x, y;
            
            iss >> timestamp;
            meas_package.timestamp_ = timestamp;
            measurement_pack_list.push_back(meas_package);
            
            
        } else if (sensor_type.compare("R") == 0) {
            // RADAR MEASUREMENT
            
            // read measurements at this timestamp
            meas_package.sensor_type_ = MeasurementPackage::RADAR;
            meas_package.raw_measurements_ = VectorXd(3);
            meas_package.raw_measurements_radarcartesian_= VectorXd(3);
            double ro;
            double theta;
            double ro_dot;
            iss >> ro;
            iss >> theta;
            iss >> ro_dot;
            meas_package.raw_measurements_ << ro, theta, ro_dot; //612 x 4
            double rc = ro * cos(theta);
            double rs = ro * sin(theta);
            // er = cosθi+sinθj
            double er= cos(theta)+sin(theta);
            // v = r ̇ er + rθ ̇ eθ
            double v = ro_dot*er;
            //cout <<"Radar measurement: "<< ro <<" "<< theta <<"  "<< ro_dot <<"  "<< rc <<"  "<< rs <<"  "<< v << endl;
            
            meas_package.raw_measurements_radarcartesian_ << rc, rs, v; //612 x 4
            
            iss >> timestamp;
            meas_package.timestamp_ = timestamp;
            measurement_pack_list.push_back(meas_package);
            
            
        }
        
        // read ground truth data to compare later
        double x_gt;
        double y_gt;
        double vx_gt;
        double vy_gt;
        iss >> x_gt;
        iss >> y_gt;
        iss >> vx_gt;
        iss >> vy_gt;
        gt_package.gt_values_ = VectorXd(4);
        gt_package.gt_values_ << x_gt, y_gt, vx_gt, vy_gt;
        gt_pack_list.push_back(gt_package);
        
    }
    
    
    UKF ukf;
    
    
    // used to compute the RMSE later
    vector<VectorXd> estimations;
    vector<VectorXd> ground_truth;
    
    // column names for output file
    out_file_ << "px" << "\t";
    out_file_ << "py" << "\t";
    out_file_ << "v" << "\t";
    out_file_ << "yaw_angle" << "\t";
    out_file_ << "yaw_rate" << "\t";
    out_file_ << "px_measured" << "\t";
    out_file_ << "py_measured" << "\t";
    out_file_ << "px_true" << "\t";
    out_file_ << "py_true" << "\t";
    out_file_ << "vx_true" << "\t";
    out_file_ << "vy_true" << "\t";
    out_file_ << "NIS" << "\t";
    out_file_ << "RMSE_px" << "\t";
    out_file_ << "RMSE_py" << "\t";
    out_file_ << "RMSE_vx" << "\t";
    out_file_ << "RMSE_vy" << "\n";
    //Call the UKF-based fusion
    size_t N = measurement_pack_list.size();
    cout << "Size of file : " << N << endl;//1224 for first file
    ukf.previous_timestamp_ =0;
    ukf.current_timestamp_ =0;
    ukf.use_radar_ = 1;
    ukf.use_laser_ = 1;
    
    for (size_t k = 0; k < N; ++k)
    {
        
        linecount++;
        
        /*
        //debug stop iteration
        if(linecount > 1224)
         {
         cout << "STOP linecount :" << linecount << " k : " << k << endl;
         exit(0);
         }
        */
        //speed starts to kick in at line count 5
        if((measurement_pack_list[k].raw_measurements_(0)==0) && (measurement_pack_list[k].raw_measurements_(1) ==0))
        {
            cout << " Line " << linecount << " skipped " << endl;
            continue;
        }
        
        {
            ukf.ProcessMeasurement(measurement_pack_list[k]);
            
            // output the estimation
            out_file_ << ukf.x_(0) << "\t"; //pos1 - est
            out_file_ << ukf.x_(1) << "\t"; //pos2 - est
            out_file_ << ukf.x_(2) << "\t"; // vel_abs - est
            out_file_ << ukf.x_(3) << "\t"; //yaw_angle - est
            out_file_ << ukf.x_(4) << "\t"; //yaw_rate - est
            //cout << "state x " << ukf.x_ << endl; //pos1 - est
            
            
            // output the measurements
            
            if (measurement_pack_list[k].sensor_type_ == MeasurementPackage::LASER) {
                // output the estimation
                out_file_ << measurement_pack_list[k].raw_measurements_(0) << "\t";
                out_file_ << measurement_pack_list[k].raw_measurements_(1) << "\t";
            } else if (measurement_pack_list[k].sensor_type_ == MeasurementPackage::RADAR) {
                // output the estimation in the cartesian coordinates
                double ro = measurement_pack_list[k].raw_measurements_(0);
                double phi = measurement_pack_list[k].raw_measurements_(1);
                double ro_dot = measurement_pack_list[k].raw_measurements_(2);
                double er= cos(phi)+sin(phi);
                out_file_ << ro * cos(phi) << "\t"; // p1_meas px
                out_file_ << ro * sin(phi) << "\t"; // ps_meas py
                // v = r ̇ er + rθ ̇ eθ
                double v = ro_dot*er;
                
                out_file_ << v << "\t"; // ps_meas py
            }
            
            // output the ground truth packages
            out_file_ << gt_pack_list[k].gt_values_(0) << "\t";
            out_file_ << gt_pack_list[k].gt_values_(1) << "\t";
            out_file_ << gt_pack_list[k].gt_values_(2) << "\t";
            out_file_ << gt_pack_list[k].gt_values_(3) << "\t";
            
            
            // output the NIS values
            
            if (measurement_pack_list[k].sensor_type_ == MeasurementPackage::LASER) {
                out_file_ << ukf.NIS_laser_ << "\t";
            } else if (measurement_pack_list[k].sensor_type_ == MeasurementPackage::RADAR) {
                out_file_ << ukf.NIS_radar_ << "\t";
            }
            
            
            // convert ukf x vector to cartesian to compare to ground truth
            VectorXd ukf_x_cartesian_ = VectorXd(4);
            
            float x_estimate_  = ukf.x_(0);
            float y_estimate_  = ukf.x_(1);
            float vx_estimate_ = ukf.x_(2) * cos(ukf.x_(3));
            float vy_estimate_ = ukf.x_(2) * sin(ukf.x_(3));
            
            ukf_x_cartesian_ << x_estimate_, y_estimate_, vx_estimate_, vy_estimate_;
            //cout << "estimate "<< x_estimate_<<" "<< y_estimate_<<" "<< vx_estimate_<<" "<< vy_estimate_<< endl;
            //cout << "cartesian "<< ukf_x_cartesian_ << endl;
            
            estimations.push_back(ukf_x_cartesian_);
            ground_truth.push_back(gt_pack_list[k].gt_values_);
            //cout << "ground truth "<< gt_pack_list[k].gt_values_ << endl;
        
            Tools tools;
            VectorXd ttx = Eigen::VectorXd(4);
            ttx <<  tools.CalculateRMSE(estimations, ground_truth);
            
            char lastChar = in_file_name_.at( in_file_name_.length() - 5 );
            cout << "lastchar " << lastChar << endl;
            
            if(lastChar == '1')
            {
                
                if ((k%2)==0)
                {
                    /*save Radar results */
                    
                    if(ukf.use_radar_ == 1)
                    {
                        out_file_ << ttx[0] << "\t" << ttx[1] << "\t" <<ttx[2] << "\t" << ttx[3] << "\n" << endl;
                        cout << "Radar measure[" << k <<"]"<< endl;
                        printResult(ttx,k,ukf, measurement_pack_list,linecount, gt_pack_list);
                    }
                }else
                {
                    /*save Laser results*/
                    
                    if(ukf.use_laser_ == 1)
                    {
                        out_file_ << ttx[0] << "\t" << ttx[1] << "\t" <<ttx[2] << "\t" << ttx[3] << "\n" << endl;
                        cout << "Lidar measure[" << k <<"]:" << endl;
                        printResult(ttx,k,ukf, measurement_pack_list,linecount, gt_pack_list);
                    }
                }
                
            }
            else
            {
                
                if ((k%2)==0)
                {
                    if(ukf.use_laser_ == 1)
                    {
                        out_file_ << ttx[0] << "\t" << ttx[1] << "\t" <<ttx[2] << "\t" << ttx[3] << "\n" << endl;
                        cout << "Lidar measure[" << k <<"]"<< endl;
                        printResult(ttx,k,ukf, measurement_pack_list,linecount, gt_pack_list);
                    }
                }else
                {
                    if(ukf.use_radar_ == 1)
                    {
                        out_file_ << ttx[0] << "\t" << ttx[1] << "\t" <<ttx[2] << "\t" << ttx[3] << "\n" << endl;
                        cout << "Radar measure[" << k <<"]:" << endl;
                        printResult(ttx,k,ukf, measurement_pack_list,linecount, gt_pack_list);
                    }
                }
            }
        }
    }
    
    
    
    
    
    // close files
    if (out_file_.is_open()) {
        out_file_.close();
    }
    
    if (in_file_.is_open()) {
        in_file_.close();
    }
    
    cout << "Done!" << endl;
    return 0;
    
}
void printResult(VectorXd ttx,int k,UKF ukf, vector<MeasurementPackage> measurement_pack_list,int linecount, vector<GroundTruthPackage> gt_pack_list)
{
    cout << "Measure [" << k << "]  Accuracy - RMSE:[px " << ttx[0] <<", py "<<ttx[1]<<",  vx  "<<ttx[2]<<",  vy  "<<ttx[3] << "   ]"<< " NIS_radar " << ukf.NIS_radar_ << " NISlaser " << ukf.NIS_laser_ << endl;
    cout << "Requirements :      [px 0.09/0.2,        py 0.09/0.2,        vx 0.65/0.55,       vy 0.65/0.55  ] when compared to the ground truth. " << endl;
    
    //cout << "linecount: "<< linecount << endl;
    cout << "estimations  :  ["    << ukf.x_[0] << ",   " << ukf.x_[1] << ",    " << ukf.x_[2] <<",           " << ukf.x_[3]<< "     ]"  << endl;
    cout << "Ground truth :  [" << gt_pack_list[k].gt_values_[0] << ",    "<< gt_pack_list[k].gt_values_[1] << ",     " <<  gt_pack_list[k].gt_values_[2]<< ",        " << gt_pack_list[k].gt_values_[3] << "      ]" <<endl;
    cout << " " << endl;
}

