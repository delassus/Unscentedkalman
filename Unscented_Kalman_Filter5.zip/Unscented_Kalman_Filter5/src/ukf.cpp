//
//Created by Hubert   3/28/2017
//

#include <iostream>
#include "ukf.h"
#define TIME_CONSTANT 1000000.0

using namespace std;

//initialize Unscented Kalman filter
UKF::UKF() {
    is_initialized_ =0;
    n_x_ = 5;
    n_aug_ = n_x_ + 2;
    lambda_ = 3 - n_aug_;
    NIS_radar_ = 0.0;
    
    NIS_laser_ = 0.0;
    
    previous_timestamp_ = 0;
    
    // initial state vector
    x_ = VectorXd(n_x_);

	// laser state vector
	laser_state_ = VectorXd(4);
    // initial covariance matrix
    P_ = MatrixXd(n_x_, n_x_);

    // augmented sigma point state vector
    x_aug_ = VectorXd(n_aug_);

    // augmented sigma points  covariance matrix
    P_aug_ = MatrixXd(n_aug_, n_aug_ );
	
    
    //RESULTS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //FILE1 stda 0.5 Measure [1223]  Accuracy - RMSE:[px 0.0829176, py 0.0906011,  vx  0.612047,  vy  0.59113   ] NIS_radar 1.73914 NISlaser 0.165853
    //FILE2 stda 0.5 Measure [199]   Accuracy - RMSE:[px 0.182744, py 0.216238,    vx  0.339185,  vy  0.445091   ] NIS_radar 0.533359 NISlaser 0.0123653
    // Process noise standard deviation longitudinal acceleration in m/s^2
    std_a_ = 0.5;
    std_yawdd_ = 0.5;
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Laser measurement noise standard deviation position1 in m
    std_laspx_ = 0.15;

    // Laser measurement noise standard deviation position2 in m
    std_laspy_ = 0.15;

    // Radar measurement noise standard deviation radius in m
   std_radr_ = 0.3;
	
    // Radar measurement noise standard deviation angle in rad
   std_radphi_ = 0.03;
	
    // Radar measurement noise standard deviation radius change in m/s
   std_radrd_ = 0.3;

    
    Xsig_pred_ = MatrixXd(n_x_, 2 * n_aug_ + 1);

    
    Xsig_aug_= MatrixXd(n_aug_, 2 * n_aug_ + 1);

    weights_ = VectorXd(2 * n_aug_ + 1);

    //sigma point matrix
    MatrixXd Xsig_aug_ = MatrixXd(n_aug_, 2 * n_aug_ + 1);

    //radar measure dimension (rho , phi, rhodot)
    n_z_ = 3;

    //sigma points radar
    Zsig_ = MatrixXd(n_z_, 2 * n_aug_ + 1);

    z_pred_ = VectorXd(n_z_);

    Tc_ = MatrixXd(n_x_, n_z_);

    //Covariance matrix S
    S_ = MatrixXd(n_z_,n_z_);

	z_radar_ = VectorXd(3);

    // Laser measurement
    z_ = VectorXd(2);

	// Process matrix for laser using kalman filter and not unscented
	H_ = MatrixXd(2, 4);
	H_ << 1, 0, 0, 0,
		0, 1, 0, 0;
    /* Laser covariance matrix */
	R_laser_ = MatrixXd(2, 2);
	R_laser_ << 0.0225, 0,
		0, 0.0225;
    use_laser_ = 1;
    use_radar_ = 1;
    RMSE_estimate = VectorXd(4);
}


  
UKF::~UKF() {}
void UKF::ProcessMeasurement(MeasurementPackage meas_package) {
 
    /*****************************************************************************
    *  Initialization
    ****************************************************************************/

 
    if (!is_initialized_) {
       // first measurement

        if (meas_package.sensor_type_ == MeasurementPackage::RADAR)
        {
			
            //Initialize the state x_ with the first measurement
            x_[0] = (double) meas_package.raw_measurements_[0] * cos(meas_package.raw_measurements_[1]);
            x_[1] = (double) meas_package.raw_measurements_[0] * sin(meas_package.raw_measurements_[1]);
            x_[2] = 0.0;
            x_[3] = 0.0;
            x_[4] = 0.0;
			
        }
        else if (meas_package.sensor_type_ == MeasurementPackage::LASER) {
            
            /* if the measurement is zero subsitute a small value for stability purpose */
            if (fabs(meas_package.raw_measurements_[0]) < 0.0001 & fabs(meas_package.raw_measurements_[1]) < 0.0001) 
					{
						meas_package.raw_measurements_[0] = 0.001;
						meas_package.raw_measurements_[1] = 0.001;
					}
            
            
            //Initialize the state x_ with the first measurement
            
            x_[0] = (double) meas_package.raw_measurements_[0];
            x_[1] = (double) meas_package.raw_measurements_[0];
            x_[2] = 0.0;
            x_[3] = 0.0;
            x_[4] = 0.0;

        }
        
        
        
        previous_timestamp_ = meas_package.timestamp_;
        P_ << MatrixXd::Identity(n_x_,n_x_);  // initialization with identity matrix works as well as any tuned matrix!
        
        
        is_initialized_ = 1;
        return;
    }

    /*****************************************************************************
     *  Prediction
     ****************************************************************************/
    
    AugmentedSigmaPoints();
    delta_t_  = (meas_package.timestamp_ - previous_timestamp_)/TIME_CONSTANT;
	previous_timestamp_ = meas_package.timestamp_;
	
		
    SigmaPointPrediction(delta_t_ );

    PredictMeanAndCovariance();


    /*****************************************************************************
     *  Update
     ****************************************************************************/


    //update the state vector with the LIDAR measurement
    //In this case we use the regular kalman filter, not the unscented.
    if (meas_package.sensor_type_ == MeasurementPackage::LASER) {
        UpdateLidar(meas_package);
    } else {
        //predict the measurement for the radar
        PredictRadarMeasurement();
        // update the state vector using the radar measurement
        UpdateRadar(meas_package);
    }

}


void UKF::AugmentedSigmaPoints() {
    /* This is as in the course */

    //Augmented covariance matrix
    // The top left is the covariance matrix P
    //The bottom right is the std_a and std_yawdd
    
    P_aug_.fill(0.0);
    P_aug_.topLeftCorner(5,5) = P_;
    P_aug_(5,5) = std_a_*std_a_;
    P_aug_(6,6) = std_yawdd_*std_yawdd_;
    
    //Augmented mean state
    x_aug_.head(5) = x_;
    x_aug_(5) = 0;
    x_aug_(6) = 0;

    //Cholesky matrix
    MatrixXd L = P_aug_.llt().matrixL();
    
    Xsig_aug_.col(0)  = x_aug_;
    for (int i = 0; i< n_aug_; i++)
    {
        Xsig_aug_.col(i+1)       = x_aug_ + sqrt(lambda_+n_aug_) * L.col(i);
        Xsig_aug_.col(i+1+n_aug_) = x_aug_ - sqrt(lambda_+n_aug_) * L.col(i);
    }
}

void UKF::SigmaPointPrediction(const double delta_t ) {
    /* This is as in the course */
    //predict sigma points
    for (int i = 0; i< 2*n_aug_+1; i++)
    {
        //extract values for better readability
        double p_x = Xsig_aug_(0,i);
        double p_y = Xsig_aug_(1,i);
        double v = Xsig_aug_(2,i);
        double yaw = Xsig_aug_(3,i);
        double yawd = Xsig_aug_(4,i);
        double nu_a = Xsig_aug_(5,i);
        double nu_yawdd = Xsig_aug_(6,i);

        //predicted state values
        double px_p, py_p;
       
        //avoid division by zero
        if (fabs(yawd) > 0.001) {
            px_p = p_x + v/yawd * ( sin (yaw + yawd*delta_t) - sin(yaw));
            py_p = p_y + v/yawd * ( cos(yaw) - cos(yaw+yawd*delta_t) );
        }
        else {
            px_p = p_x + v*delta_t*cos(yaw);
            py_p = p_y + v*delta_t*sin(yaw);
        }

        double v_p = v;
        double yaw_p = yaw + yawd*delta_t;
        double yawd_p = yawd;

        //add noise
        px_p = px_p + 0.5*nu_a*delta_t*delta_t * cos(yaw);
        py_p = py_p + 0.5*nu_a*delta_t*delta_t * sin(yaw);
        v_p = v_p + nu_a*delta_t;

        yaw_p = yaw_p + 0.5*nu_yawdd*delta_t*delta_t;
        yawd_p = yawd_p + nu_yawdd*delta_t;

        //write predicted sigma point into right column
        Xsig_pred_(0,i) = px_p;
        Xsig_pred_(1,i) = py_p;
        Xsig_pred_(2,i) = v_p;
        Xsig_pred_(3,i) = yaw_p;
        Xsig_pred_(4,i) = yawd_p;
    }


}


void UKF::PredictMeanAndCovariance(){
    /* This is as in the course */

    
    double weight_0 = lambda_/(lambda_+n_aug_);
    weights_(0) = weight_0;
    for (int i=1; i<2*n_aug_+1; i++) {
        double weight = 0.5/(n_aug_+lambda_);
        weights_(i) = weight;
    }

    
    x_.fill(0.0);
    for (int i = 0; i < 2 * n_aug_ + 1; i++) {
        x_ = x_+ weights_(i) * Xsig_pred_.col(i);
    }

    //predicted state covariance matrix
    P_.fill(0.0);
    for (int i = 0; i < 2 * n_aug_ + 1; i++) {

        // mesure state innovation
  		VectorXd x_diff = Xsig_pred_.col(i) - x_;
		
		
        //angle normalization
        x_diff(3) = wrapAngle(x_diff(3));
       
	
        P_ = P_ + weights_(i) * x_diff * x_diff.transpose();
    }
//cout << "P matrix is " << endl << P_ << endl;
}


void UKF::PredictRadarMeasurement() {
    //transform sigma points into measurement space
    for (int i = 0; i < 2 * n_aug_ + 1; i++) {  //2n+1 simga points
        // extract values for better readibility
        double p_x = Xsig_pred_(0,i);
        double p_y = Xsig_pred_(1,i);
        double v  = Xsig_pred_(2,i);
        double yaw = Xsig_pred_(3,i);

        double v1 = cos(yaw)*v;
        double v2 = sin(yaw)*v;

        // measurement model
		if (fabs(p_x)<0.001 && fabs(p_y)<0.001) {
			p_x = 0.001;
			p_y = 0.001;
			}

			Zsig_(0, i) = sqrt(p_x*p_x + p_y*p_y);  // r
			Zsig_(1, i) = atan2(p_y, p_x);			// phi
			Zsig_(2, i) = (p_x*v1 + p_y*v2) / sqrt(p_x*p_x + p_y*p_y);  // r_dot

		         
    }

    //mean predicted measurement

    z_pred_.fill(0.0);
    for (int i=0; i < 2*n_aug_+1; i++) {
        z_pred_ = z_pred_ + weights_(i) * Zsig_.col(i);
    }

    S_.fill(0.0);
    for (int i = 0; i < 2 * n_aug_ + 1; i++)
    {
        //residual
        VectorXd z_diff = Zsig_.col(i) - z_pred_;
        //angle normalization
        z_diff(1) = wrapAngle(z_diff(1));
        S_ = S_ + weights_(i) * z_diff * z_diff.transpose();
    }

    //Add measurement noise covariance matrix to S
    
    MatrixXd R = MatrixXd(n_z_,n_z_);
    R <<    std_radr_*std_radr_, 0, 0,
            0, std_radphi_*std_radphi_, 0,
            0, 0,std_radrd_*std_radrd_;
    S_ = S_ + R;

}




void UKF::UpdateLidar(MeasurementPackage meas_package)
{
    /* This is identical to kalman filter project (No unscented Kalman filter here.)*/
    
    
    //Create the state transition process matrix
    H_ = MatrixXd(2, 5);
    H_.fill(0);
    H_ << 1, 0, 0, 0,0, 0, 1, 0, 0,0;
    z_[0] = meas_package.raw_measurements_[0];
    z_[1]=	meas_package.raw_measurements_[1];
    

	
	VectorXd z_pred = H_ * x_;
	VectorXd y = z_ - z_pred;
	MatrixXd Ht = H_.transpose();
	MatrixXd S = H_ * P_ * Ht + R_laser_;
	MatrixXd Si = S.inverse();
	MatrixXd PHt = P_ * Ht;
	MatrixXd K = PHt * Si;

	//new estimate
	x_ = x_ + (K * y);

	long long x_size = x_.size();
	MatrixXd I = MatrixXd::Identity(x_size, x_size);
	P_ = (I - K * H_) * P_;
    
    VectorXd z_diff_new = VectorXd(2);
    z_diff_new.fill(0);
    z_diff_new = z_ - toLidarSpace(x_);
    NIS_laser_ = z_diff_new.transpose()*Si*z_diff_new;
    
}

    
    





void UKF::UpdateRadar(MeasurementPackage meas_package) {
    z_radar_[0]= meas_package.raw_measurements_[0];
    z_radar_[1] = meas_package.raw_measurements_[1];
    z_radar_[2] = meas_package.raw_measurements_[2];
    
    //calculate cross correlation matrix
    Tc_.fill(0.0);
    for (int i = 0; i < 2 * n_aug_ + 1; i++) {  //2n+1 sigma points

        //residual
        VectorXd z_diff = Zsig_.col(i) - z_pred_;
        
        //angle normalization
	    z_diff(1) = wrapAngle(z_diff(1));
        
        // state difference
        VectorXd x_diff = Xsig_pred_.col(i) - x_;
        //angle normalization
        x_diff(3) = wrapAngle(x_diff(3));
       
	
        Tc_ = Tc_ + weights_(i) * x_diff * z_diff.transpose();
    }

    //Kalman gain K;
    MatrixXd K = Tc_ * S_.inverse();

    //residual
    VectorXd z_diff = z_radar_ - z_pred_;

    //angle normalization
    z_diff(1) = wrapAngle(z_diff(1));
	
    //update state mean and covariance matrix
    x_ = x_ + K * z_diff;
    P_ = P_ - K*S_*K.transpose();
    
    cout << z_radar_.size()<< endl;
    VectorXd z_diff_new = VectorXd(3);
    z_diff_new.fill(0);
    
    z_diff_new = z_radar_ - toRadarSpace(x_);

    NIS_radar_ = z_diff_new.transpose()*S_.inverse()*z_diff_new;
    
}
VectorXd UKF::toRadarSpace(MatrixXd cartesian) {
    double p_x=0, p_y=0, v=0, yaw=0, rho=0, phi=0;
    p_x = cartesian(0);
    p_y = cartesian(1);
    v = cartesian(2);
    yaw = cartesian(3);
    rho = sqrt(p_x*p_x + p_y*p_y);
    VectorXd radar(3);
    radar(0) = rho;
    phi = atan2(p_y, p_x);
    radar(1) = phi;
    if (fabs(rho) < 0.0001) {
        radar(2) = 0;
    } else {
        radar(2) = (p_x*cos(yaw) + p_y*sin(yaw))*v/rho;
    }
    return radar;
}
VectorXd UKF::toLidarSpace(MatrixXd cartesian) {
    double p_x=0, p_y=0, v=0, yaw=0;
    p_x = cartesian(0);
    p_y = cartesian(1);
    v = cartesian(2);
    yaw = cartesian(3);
    VectorXd lidar(2);
    lidar(0) = p_x;
    lidar(1) = p_y;
    
    return lidar;
}
double UKF::wrapAngle(double angle){
    while (angle> M_PI)
    {
        angle-=2.*M_PI;
    }
    while (angle<-M_PI)
    {
        angle+=2.*M_PI;
    }
    return angle;
}
