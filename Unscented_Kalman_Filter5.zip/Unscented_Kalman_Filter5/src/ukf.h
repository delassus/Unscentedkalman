//
//  ukf.h
//  KalmanProject
//
//  Created by Hubert de Lassus on 3/30/17.
//
//

#ifndef ukf_h
#define ukf_h
#include "Eigen/Dense"
#include "measurement_package.h"
using Eigen::MatrixXd;
using Eigen::VectorXd;

class UKF {
public:
    long long previous_timestamp_;
    long long current_timestamp_;
    int is_initialized_;
    // if this is one, laser measurements will be ignored (except for init)
    int use_laser_;

    // if this is zero, radar measurements will be ignored (except for init)
    int use_radar_;

    // state vector: [pos1 pos2 vel_abs yaw_angle yaw_rate] in SI units and rad
    VectorXd x_;

	VectorXd z_radar_;

    // state covariance matrix
    MatrixXd P_;

	//  laser state variable with vx and vy
	VectorXd laser_state_;

    // predicted sigma points matrix
    MatrixXd Xsig_pred_;

    // sigma vector aug
    
    VectorXd x_aug_;

    //create augmented state covariance
    MatrixXd P_aug_;

    //create sigma point matrix
    MatrixXd Xsig_aug_;

    //Measurement model radar vector
    MatrixXd Zsig_;

    
    int n_z_;

    // time when the state is true, in us
    long time_us_;

    // Process noise standard deviation longitudinal acceleration in m/s^2
    double std_a_;

    // Process noise standard deviation yaw acceleration in rad/s^2
    double std_yawdd_;

    // Laser measurement noise standard deviation position1 in m
    double std_laspx_;

    // Laser measurement noise standard deviation position2 in m
    double std_laspy_;

    // Radar measurement noise standard deviation radius in m
    double std_radr_;

    // Radar measurement noise standard deviation angle in rad
    double std_radphi_;

    // Radar measurement noise standard deviation radius change in m/s
    double std_radrd_ ;

    // Weights of sigma points
    VectorXd weights_;

    // radar prediction vector
    VectorXd z_pred_;

    //create example matrix for predicted measurement covariance
    MatrixXd S_ ;

    //create matrix for cross correlation Tc
    MatrixXd Tc_;

    MatrixXd H_ ;
	
    // lidar R function
    MatrixXd R_laser_;
    
    double delta_t_;

    // State dimension
    int n_x_;

    // Augmented state dimension
    int n_aug_;

    // Sigma point spreading parameter
    double lambda_;

    // the current NIS for radar
    double  NIS_radar_;

    // the current NIS for laser
    double NIS_laser_;

    // incoming radar measurement
    VectorXd z_;

	VectorXd RMSE_estimate;

    
     // Constructor
     
    UKF();

    
     //Destructor
    
    virtual ~UKF();

    
    void ProcessMeasurement(const MeasurementPackage meas_package);

    



    void AugmentedSigmaPoints();
    void SigmaPointPrediction(const double delta_t);
    void PredictMeanAndCovariance();
    void PredictRadarMeasurement();

    void UpdateLidar(MeasurementPackage meas_package);
    void UpdateRadar(MeasurementPackage meas_package);
    double wrapAngle(double angle);
    VectorXd toRadarSpace(MatrixXd cartesian);
    VectorXd toLidarSpace(MatrixXd cartesian);
};

#endif
