//
//Created by Hubert   3/28/2017
//

#ifndef MEASUREMENT_PACKAGE_H_
#define MEASUREMENT_PACKAGE_H_

#include "Eigen/Dense"

class MeasurementPackage {
public:
    long timestamp_;
    
    enum SensorType{
        LASER,
        RADAR
    } sensor_type_;
    
    Eigen::VectorXd raw_measurements_;
    Eigen::VectorXd raw_measurements_radarcartesian_;
};

#endif /* MEASUREMENT_PACKAGE_H_ */
